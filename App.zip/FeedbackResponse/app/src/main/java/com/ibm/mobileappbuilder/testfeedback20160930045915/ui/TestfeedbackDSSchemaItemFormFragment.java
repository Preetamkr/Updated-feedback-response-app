
package com.ibm.mobileappbuilder.testfeedback20160930045915.ui;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import com.ibm.mobileappbuilder.testfeedback20160930045915.presenters.UserfeedbacksFormPresenter;
import com.ibm.mobileappbuilder.testfeedback20160930045915.R;
import ibmmobileappbuilder.ds.CloudantDatasource;
import ibmmobileappbuilder.ui.FormFragment;
import ibmmobileappbuilder.util.StringUtils;
import ibmmobileappbuilder.views.TextWatcherAdapter;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.testfeedback20160930045915.ds.TestfeedbackDSSchemaItem;
import ibmmobileappbuilder.ds.CloudantDatasource;
import ibmmobileappbuilder.cloudant.factory.CloudantDatastoresFactory;
import java.net.URI;
import static ibmmobileappbuilder.analytics.injector.PageViewBehaviorInjector.pageViewBehavior;

public class TestfeedbackDSSchemaItemFormFragment extends FormFragment<TestfeedbackDSSchemaItem> {

    private CrudDatasource<TestfeedbackDSSchemaItem> datasource;

    public static TestfeedbackDSSchemaItemFormFragment newInstance(Bundle args){
        TestfeedbackDSSchemaItemFormFragment fr = new TestfeedbackDSSchemaItemFormFragment();
        fr.setArguments(args);

        return fr;
    }

    public TestfeedbackDSSchemaItemFormFragment(){
        super();
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        // the presenter for this view
        setPresenter(new UserfeedbacksFormPresenter(
                (CrudDatasource) getDatasource(),
                this));

        addBehavior(pageViewBehavior("Userfeedbacks"));
    }

    @Override
    protected TestfeedbackDSSchemaItem newItem() {
        return new TestfeedbackDSSchemaItem();
    }

    @Override
    protected int getLayout() {
        return R.layout.userfeedbacks_form;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final TestfeedbackDSSchemaItem item, View view) {
        
        bindString(R.id.name, item.name, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.name = s.toString();
            }
        });
        
        
        bindString(R.id.email, item.email, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.email = s.toString();
            }
        });
        
        
        bindString(R.id.phone, item.phone, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.phone = s.toString();
            }
        });
        
        
        bindString(R.id.organisation, item.organisation, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.organisation = s.toString();
            }
        });
        
        
        bindDouble(R.id.rating, item.rating, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.rating = StringUtils.parseDouble(s.toString());
            }
        });
        
        
        bindString(R.id.comments, item.comments, new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                item.comments = s.toString();
            }
        });
        
    }

    @Override
    public Datasource<TestfeedbackDSSchemaItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = CloudantDatasource.cloudantDatasource(
              CloudantDatastoresFactory.create("testfeedback"),
              URI.create("https://63c774e2-582a-4e2a-890a-d34e3d6a9bdf-bluemix:fffe14301f9bcd0a44946e95c1d34cbaac78e026d47b2e1eca9dd27f497ac973@63c774e2-582a-4e2a-890a-d34e3d6a9bdf-bluemix.cloudant.com/testfeedback"),
              TestfeedbackDSSchemaItem.class,
              new SearchOptions(),
              null
      );
        return datasource;
    }
}

