package ibmmobileappbuilder.mvp.presenter;

public abstract class BasePresenter implements Presenter {

    @Override
    public void startPresenting() {

    }

    @Override
    public void stopPresenting() {

    }
}
