

package com.ibm.mobileappbuilder.testfeedback20160930045915.ui;

import android.os.Bundle;
import android.support.v4.app.Fragment;

import com.ibm.mobileappbuilder.testfeedback20160930045915.R;

import ibmmobileappbuilder.ui.BaseListingActivity;
/**
 * UserfeedbacksActivity list activity
 */
public class UserfeedbacksActivity extends BaseListingActivity {

    @Override
    protected void onCreate(Bundle savedInstance) {
        super.onCreate(savedInstance);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setTitle(getString(R.string.userfeedbacksActivity));
    }

    @Override
    protected Class<? extends Fragment> getFragmentClass() {
        return UserfeedbacksFragment.class;
    }

}

