
package com.ibm.mobileappbuilder.testfeedback20160930045915.ds;

import ibmmobileappbuilder.mvp.model.MutableIdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class ResponsetofeedbackDSSchemaItem implements Parcelable, MutableIdentifiableBean {

    private transient String cloudantIdentifiableId;

    @SerializedName("Customer_name") public String customer_name;
    @SerializedName("customer_contact") public String customer_contact;
    @SerializedName("customer_email") public String customer_email;
    @SerializedName("customer_satisfaction") public String customer_satisfaction;

    @Override
    public void setIdentifiableId(String id) {
        this.cloudantIdentifiableId = id;
    }

    @Override
    public String getIdentifiableId() {
        return cloudantIdentifiableId;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(cloudantIdentifiableId);
        dest.writeString(customer_name);
        dest.writeString(customer_contact);
        dest.writeString(customer_email);
        dest.writeString(customer_satisfaction);
    }

    public static final Creator<ResponsetofeedbackDSSchemaItem> CREATOR = new Creator<ResponsetofeedbackDSSchemaItem>() {
        @Override
        public ResponsetofeedbackDSSchemaItem createFromParcel(Parcel in) {
            ResponsetofeedbackDSSchemaItem item = new ResponsetofeedbackDSSchemaItem();
            item.cloudantIdentifiableId = in.readString();

            item.customer_name = in.readString();
            item.customer_contact = in.readString();
            item.customer_email = in.readString();
            item.customer_satisfaction = in.readString();
            return item;
        }

        @Override
        public ResponsetofeedbackDSSchemaItem[] newArray(int size) {
            return new ResponsetofeedbackDSSchemaItem[size];
        }
    };
}


