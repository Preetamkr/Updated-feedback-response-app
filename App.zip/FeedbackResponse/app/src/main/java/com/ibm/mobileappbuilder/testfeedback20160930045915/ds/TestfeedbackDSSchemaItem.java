
package com.ibm.mobileappbuilder.testfeedback20160930045915.ds;

import ibmmobileappbuilder.mvp.model.MutableIdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class TestfeedbackDSSchemaItem implements Parcelable, MutableIdentifiableBean {

    private transient String cloudantIdentifiableId;

    @SerializedName("name") public String name;
    @SerializedName("email") public String email;
    @SerializedName("phone") public String phone;
    @SerializedName("organisation") public String organisation;
    @SerializedName("rating") public Double rating;
    @SerializedName("comments") public String comments;

    @Override
    public void setIdentifiableId(String id) {
        this.cloudantIdentifiableId = id;
    }

    @Override
    public String getIdentifiableId() {
        return cloudantIdentifiableId;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(cloudantIdentifiableId);
        dest.writeString(name);
        dest.writeString(email);
        dest.writeString(phone);
        dest.writeString(organisation);
        dest.writeValue(rating);
        dest.writeString(comments);
    }

    public static final Creator<TestfeedbackDSSchemaItem> CREATOR = new Creator<TestfeedbackDSSchemaItem>() {
        @Override
        public TestfeedbackDSSchemaItem createFromParcel(Parcel in) {
            TestfeedbackDSSchemaItem item = new TestfeedbackDSSchemaItem();
            item.cloudantIdentifiableId = in.readString();

            item.name = in.readString();
            item.email = in.readString();
            item.phone = in.readString();
            item.organisation = in.readString();
            item.rating = (Double) in.readValue(null);
            item.comments = in.readString();
            return item;
        }

        @Override
        public TestfeedbackDSSchemaItem[] newArray(int size) {
            return new TestfeedbackDSSchemaItem[size];
        }
    };
}


