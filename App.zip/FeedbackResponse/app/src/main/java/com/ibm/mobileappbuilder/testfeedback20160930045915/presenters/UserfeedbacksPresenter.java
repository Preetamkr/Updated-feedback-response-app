
package com.ibm.mobileappbuilder.testfeedback20160930045915.presenters;

import com.ibm.mobileappbuilder.testfeedback20160930045915.R;
import com.ibm.mobileappbuilder.testfeedback20160930045915.ds.TestfeedbackDSSchemaItem;

import java.util.List;

import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.mvp.presenter.BasePresenter;
import ibmmobileappbuilder.mvp.presenter.ListCrudPresenter;
import ibmmobileappbuilder.mvp.view.CrudListView;
import java.util.Map;
import java.util.HashMap;
import ibmmobileappbuilder.analytics.injector.AnalyticsReporterInjector;

public class UserfeedbacksPresenter extends BasePresenter implements ListCrudPresenter<TestfeedbackDSSchemaItem>,
      Datasource.Listener<TestfeedbackDSSchemaItem>{

    private final CrudDatasource<TestfeedbackDSSchemaItem> crudDatasource;
    private final CrudListView<TestfeedbackDSSchemaItem> view;

    public UserfeedbacksPresenter(CrudDatasource<TestfeedbackDSSchemaItem> crudDatasource,
                                         CrudListView<TestfeedbackDSSchemaItem> view) {
       this.crudDatasource = crudDatasource;
       this.view = view;
    }

    @Override
    public void deleteItem(TestfeedbackDSSchemaItem item) {
        crudDatasource.deleteItem(item, this);
    }

    @Override
    public void deleteItems(List<TestfeedbackDSSchemaItem> items) {
        crudDatasource.deleteItems(items, this);
    }

    @Override
    public void addForm() {
        view.showAdd();
    }

    @Override
    public void editForm(TestfeedbackDSSchemaItem item, int position) {
        view.showEdit(item, position);
    }

    @Override
    public void detail(TestfeedbackDSSchemaItem item, int position) {
        view.showDetail(item, position);
    }

    @Override
    public void onSuccess(TestfeedbackDSSchemaItem item) {
        logCrudAction("deleted", item.getIdentifiableId());
        view.showMessage(R.string.items_deleted);
        view.refresh();
    }

    @Override
    public void onFailure(Exception e) {
        view.showMessage(R.string.error_data_generic);
    }

    private void logCrudAction(String action, String id) {
      Map<String, String> paramsMap = new HashMap<>(3);
      //action will be one of created, updated or deleted
      paramsMap.put("action", action);
      paramsMap.put("entity", "TestfeedbackDSSchemaItem");
      paramsMap.put("identifier", id);

      AnalyticsReporterInjector.analyticsReporter().sendEvent(paramsMap);
    }
}

